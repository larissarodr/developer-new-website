module.exports = {
  EMAIL_USER: 'ZmFsZWNvbm9zY29AZGV2ZWxvcGVyLmluZi5icg==', 
  EMAIL_PASS: 'MjAyMCFAI0Rldg==',
  DB_NAME: 'ZGV2ZWw2MTdfc3Vwb3J0ZQ==',
  DB_USER: 'ZGV2ZWw2MTdfZ2xwaQ==',
  DB_PASS: 'aWRjYjQw'
}