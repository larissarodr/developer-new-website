const app = require('./app');

app.listen(3000, '127.0.0.1');